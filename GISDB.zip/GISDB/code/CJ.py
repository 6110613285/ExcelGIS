import requests
from datetime import datetime
import pandas as pd
import re 
import csv
import time
import mysql.connector
import pymysql, os, json
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import create_engine

now = datetime.today()

list_province_in_thai = []
list_district_in_thai = []
list_subdistrict_in_thai = []
label = pd.read_excel('../code/geocodelabel.xlsx', index_col=None)
for i in range(len(label)):
    list_province_in_thai.append(label['name_th'][i])
    list_district_in_thai.append(label['district_name_th'][i])
    list_subdistrict_in_thai.append(label['subdistrict_name_th'][i])

# clear dup
list_province_in_thai = list(dict.fromkeys(list_province_in_thai))
list_district_in_thai = list(dict.fromkeys(list_district_in_thai))
list_subdistrict_in_thai = list(dict.fromkeys(list_subdistrict_in_thai))

def longdoAddress(lat,lng):
    url = "https://api.longdo.com/map/services/address?"
    params = {'lat': lat , 'lon' : lng , 'key' : '1917e02b4ab264ba547fecdd6e82b4aa'}
    response =requests.get(url, params=params)
    payload = response.json()
    #print("------------------------------------------")
    #print(payload)
    #print("------------------------------------------")
    province = removeWrongkeyword(payload['province'])
    district = removeWrongkeyword(payload['district'])
    subdistrict = removeWrongkeyword(payload['subdistrict'])
    try:
        postcode = payload['postcode']
        
    except :
        postcode = ""
    
    time.sleep(1)
    
    return province,district,subdistrict,postcode

def extracteachDetail(word):
    payload_word = word
    if(re.findall(r"\จังหวัด",payload_word)):
        payload_word = re.sub("จังหวัด","",payload_word)
    elif(re.findall(r"\อำเภอ",payload_word)):
        payload_word = re.sub("อำเภอ","",payload_word)
    elif(re.findall(r"\ตำบล",payload_word)):
        payload_word = re.sub("ตำบล","",payload_word)
    elif(re.findall(r"\เขต",payload_word)):
        payload_word = re.sub("เขต","",payload_word)
    elif(re.findall(r"\แขวง",payload_word)):
        payload_word = re.sub("แขวง","",payload_word)
        
    return payload_word

def removeWrongkeyword(word):
    payload_word = word
    if(re.findall(r"\จ+[.]",word)):
        payload_word = re.sub(r"\จ+[.]","จังหวัด",word)
    elif(re.findall(r"\อ+[.]",word)):
        payload_word = re.sub(r"\อ+[.]","อำเภอ",word)
    elif(re.findall(r"\ต+[.]",word)):
        payload_word = re.sub(r"\ต+[.]","ตำบล",word)
    return payload_word
        
def getdataFromAPI():
    url = "https://www.cjexpress.co.th/branch/all"
    response = requests.get(url)
    payload = response.json()
    with open(f'../trash/CJ{str(now.date())}.json', 'w') as f:
        json.dump(payload, f)

getdataFromAPI()

t = open(f'../trash/CJ{str(now.date())}.json')
payload = json.load(t)

def getAddressDetail(address,lat,lng):
    str_address = address.replace("  "," ")
    #print(str_address)

    #remove newline 
    if("\n" in str_address) :
        str_address = re.sub('\r','',str_address)
        str_address = re.sub('\n',' ',str_address)
    #print(str_address)
    # fix missing keyword
    temp_fix = str_address.split()
    
    if(len(temp_fix[-3]) == 2):
        temp_fix.pop(-3)
    
        #check if don't have postcode or missing keyword
    if(re.findall("[ก-ฮ]", temp_fix[-1])):
        #print(str_address)
        #print(temp_fix[-1])
            #find missing province 
        if(temp_fix[-1] not in list_province_in_thai):
            # 0 = จังหวัด , 1 = อำเภอ , 2 = ตำบล
            pro,_,_,postcode = longdoAddress(lat,lng)
            temp_fix.append(pro)
            temp_fix.append(postcode)
            #print(temp_fix)
            time.sleep(5)
    
    else :
        if(re.findall("[ก-ฮ]", temp_fix[-2])):
            #print("yest")
            # check and fix province contain จ.
            if(re.findall(r"\จ+[.]", temp_fix[-2])):
                temp_fix[-2] = removeWrongkeyword(temp_fix[-2])
            if(re.findall(r"\อ+[.]", temp_fix[-3])):
                temp_fix[-3] = removeWrongkeyword(temp_fix[-3])
            if(re.findall(r"\ต+[.]", temp_fix[-4])):
                temp_fix[-4] = removeWrongkeyword(temp_fix[-4])
    
    #fix prefix 
    if(not re.findall("จังหวัด", temp_fix[-2])):
        temp_fix[-2] = "จังหวัด"+ temp_fix[-2]
    if(not re.findall("อำเภอ", temp_fix[-3])):
        temp_fix[-3] = "อำเภอ"+ temp_fix[-3]
    if(not re.findall("ตำบล", temp_fix[-4])):
        temp_fix[-4] = "ตำบล"+ temp_fix[-4]
    fix_address = ""
    for j in temp_fix :
        fix_address = fix_address + j + " "
    
    #print(fix_address)
    
    # get each detail
    province = temp_fix[-2].replace("จังหวัด","")
    district = temp_fix[-3].replace("อำเภอ","")
    subdistrict = temp_fix[-4].replace("ตำบล","")
    
    is_find = False
    
    if(province == "กรุงเทพฯ"):
        province = province.replace("กรุงเทพฯ","กรุงเทพมหานคร")
    if(province not in list_province_in_thai):
        print(str_address)
        is_find = True
        province,district,subdistrict,postcode = longdoAddress(lat,lng)
        postcode = extracteachDetail(postcode)
        province = extracteachDetail(province)
        district = extracteachDetail(district)
        subdistrict = extracteachDetail(subdistrict)
    if(district not in list_district_in_thai):
        if(not is_find):
            print(str_address)
            is_find = True
            province,district,subdistrict,postcode = longdoAddress(lat,lng)
            postcode = extracteachDetail(postcode)
            province = extracteachDetail(province)
            district = extracteachDetail(district)
            subdistrict = extracteachDetail(subdistrict)
    if(subdistrict not in subdistrict):
        if(not is_find):
            print(str_address)
            is_find = True
            province,district,subdistrict,postcode = longdoAddress(lat,lng)
            postcode = extracteachDetail(postcode)
            province = extracteachDetail(province)
            district = extracteachDetail(district)
            subdistrict = extracteachDetail(subdistrict)
    
    
    '''
    print("province: "+ province)
    print("district: "+district)
    print("subdistrict: "+subdistrict)
    print("-------------------------------------------")
    '''
    return fix_address,province,district,subdistrict

def getStorename(id):
    store_type = ""
    if(id == 0):
        store_type = "CJ Supermarket"
    elif(id == 1):
        store_type = "CJ Express"
    return store_type

def getStoretype(id):
    store_type = ""
    if(id == 0):
        store_type = "Supermarket"
    elif(id == 1):
        store_type = "Convenience Stores"
    return store_type

list_CJ_supermarket = []
list_CJ_express = []
for i in range(len(payload)):
    name = payload[i]['branch']
    store_id = payload[i]['code']
    address = payload[i]['address']
    lat = payload[i]['lat']
    lng = payload[i]['lng']
    no_type = payload[i]['card']
    address,province,district,subdistrict = getAddressDetail(address,lat,lng)
    store_name = getStorename(no_type)
    store_type = getStoretype(no_type)
    dict_CJ = {"name" : name , "store_id" : store_id,
                        "name_store" : store_name , "store_type" : store_type,
                        "address" : address , "lat" : lat , "lng" : lng ,
                        "subdistrict" : subdistrict , "district" : district ,"province" : province 
                }
    if(no_type == 0) :
        list_CJ_supermarket.append(dict_CJ)
    elif(no_type == 1):
        list_CJ_express.append(dict_CJ)
        
    #print(i)

with open(f"../trash/CJsupermarket{str(now.date())}.json"  , "w") as outfile:
            json.dump(list_CJ_supermarket, outfile)
with open(f"../trash/CJexpress{str(now.date())}.json"  , "w") as outfile:
            json.dump(list_CJ_express, outfile)

df_json =  pd.read_json(f"../trash/CJexpress{str(now.date())}.json")
df_json.to_excel(f"../excel/CJ/CJexpress/CJexpress({str(now.date())}).xlsx")
df_json.to_csv(f"../csv/CJ/CJexpress/CJexpress({str(now.date())}).csv")

df_json =  pd.read_json(f"../trash/CJsupermarket{str(now.date())}.json")
df_json.to_excel(f"../excel/CJ/CJsupercenter/CJsupermarket({str(now.date())}).xlsx")
df_json.to_csv(f"../csv/CJ/CJsupercenter/CJsupermarket({str(now.date())}).csv")
"""
#TODBCJ
ce = pd.read_csv(f'../csv/CJ/CJexpress/CJexpress{str(now.date())}.csv', header = 0)
cs = pd.read_csv(f'../csv/CJ/CJsupercenter/CJsupermarket{str(now.date())}.csv', header = 0)
engine = create_engine('mysql://root:@localhost:3306/cjexpress')
with engine.connect() as conn, conn.begin():
    ce.to_sql(f'CJexpress{str(now.date())}', conn, if_exists='append', index=False)
conn.close()
engine = create_engine('mysql://root:@localhost:3306/cjsupermarket')
with engine.connect() as conn, conn.begin():
    cs.to_sql(f'CJsupermarket{str(now.date())}', conn, if_exists='append', index=False)
conn.close()
"""