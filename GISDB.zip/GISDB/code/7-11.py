import requests
from datetime import datetime
import pandas as pd
import re 
import csv
import json
import time
import random
now = datetime.today()
def getSevenBySearchKeyword(keyword):
    url = "https://7eleven-api-prod.jenosize.tech/v1/Store/GetStoreBySearch"
    headers = {'Accept': 'application/json, text/plain, */*'}
    form_data = {"keyword": keyword }
    response = requests.post(url, headers=headers , data=form_data)
    #response = requests.post(url, headers=headers)
    payload = response.json()
    return payload

list_province_in_thai = []
list_district_in_thai = []
list_subdistrict_in_thai = []
label = pd.read_excel('../CODE/geocodelabel.xlsx', index_col=None)
for i in range(len(label)):
    list_province_in_thai.append(label['name_th'][i])
    list_district_in_thai.append(label['district_name_th'][i])
    list_subdistrict_in_thai.append(label['subdistrict_name_th'][i])

# clear dup
list_province_in_thai = list(dict.fromkeys(list_province_in_thai))

count = 0
for i in  list_province_in_thai:
    if(i == "กาฬสินธุ์"):
        print(count)
    count = count + 1

list_test = []
p = 0
# 5
percent = 77
df = pd.DataFrame(columns =["province" ,"subdistrict","store"])
#len(list_province_in_thai)
while p < percent:
    province_tag = list_province_in_thai[p]
    print("index propince of: " + str(p) + " province: " + province_tag)
    index = 0
    list_subdistrict_in_province = []
    while index < len(label):
        if(province_tag == label['name_th'][index]):
            list_subdistrict_in_province.append(label['subdistrict_name_th'][index])
            index = index + 1
        else :
            index = index + 1
    
    list_7_11_code = []
    list_stores = []
    i = 0
    list_storeinsub = []

    #print(list_subdistrict_in_province)
   
    while i < (len(list_subdistrict_in_province))  :
        subdistrict = list_subdistrict_in_province[i]
        #print(subdistrict)
        #print("index subtrict of: " + str(i) +"/"+ str(len(list_subdistrict_in_province)-1) + " subdistrict: " + subdistrict)
        payload = getSevenBySearchKeyword(subdistrict)
        data = payload['data']
        length = len(data)
        #print(length)
        
        df = df.append({"province":province_tag, "subdistrict":subdistrict, "store":length}, ignore_index=True)
        list_storeinsub.append(df)

        for seven in data :
            code_id = seven['id']
            lat = seven['lat']
            lng = seven['lng']
            name = seven['name']
            products = seven['products']
            try:
                address = seven['address']
            except :
                address = "-"
            try : 
                province = seven['province']
            except : 
                province = "-"
            try :
                district = seven['district']
            except: 
                district = "-"
            try : 
                subdistrict = seven['subdistrict']
            except :
                subdistrict = "-"
            try :
                postcode = seven['postcode']
            except :
                postcode = "-"
            
            try : 
                renovate = seven['renovate']
            except :
                renovate = "-"
            if(province == province_tag):
                if(code_id not in list_7_11_code):
                    list_7_11_code.append(code_id)
                    dict_payload_7_11 = { "name" : name , "store_id" : code_id , "address" : address , "lat" : lat , "lng" : lng , 
                                 "subdistrict" : subdistrict , "district" : district , "province" : province , "postcode" : postcode , "renovate": renovate }
                
                    list_stores.append(dict_payload_7_11)
        
        
        
        i = i + 1
               
        print("percent to complete: " + str((i/len(list_subdistrict_in_province))*100) )
        time.sleep(random.randint(1,5))
        
        dict_output = {"province" : province_tag ,  "sum_store" : len(list_stores) , "stores" : list_stores}
        
        temp_sort = list_7_11_code
        temp_sort.sort()

        dict_code = {"province" : province_tag , "sum_store" : len(temp_sort) , "stores" : temp_sort }
        
        list_payload_output = []
        list_payload_output.append(dict_output)
        #"C://GISDB/csv/7-11/%s.json"
        with open("../GISDB/csv/7-11/%s.json" % province_tag  , "w") as outfile:
            json.dump(list_stores, outfile)
    
    print("extract Province: " + province_tag + " Completed ")
    
    '''list_cleaner = []
    list_code = []
    
    pro = open(f'../GISDB/trash/%s{str(now.date())}.json' % province_tag)
    payload = json.load(pro)
    stores = payload[0]['stores']
    
    for i in range (len(stores)):
        data = stores[i]
        code = stores[i]['store_id'] 
        province_temp = stores[i]['province'] 
        if(code not in list_code):
            list_code.append(code)
        if(province_tag == province_temp):
            list_cleaner.append(data)
    
    with open(f"../GISDB/csv/7-11/%s.csv" % province_tag, "w") as outfile:
            csv.DictWriter(list_cleaner, outfile)
    '''
    print("clean Province: " + province_tag + " Completed ")
    print("-----------------------------------------------------")
    print("percent to complete: " + str((p/len(list_province_in_thai))*100) )

    p = p + 1
