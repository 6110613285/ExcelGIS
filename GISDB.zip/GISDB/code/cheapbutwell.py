import requests
import json
import time
import re
import pandas as pd
from datetime import datetime

now = datetime.today()
url = 'https://api.xn--12c4alecw7cat2md3ab5c.com/graphql'

headers = {
    'Content-Type': 'application/json'
}
list_province_in_thai = []
list_district_in_thai = []
list_subdistrict_in_thai = []
label = pd.read_excel('../CODE/geocodelabel.xlsx', index_col=None)
for i in range(len(label)):
    list_province_in_thai.append(label['name_th'][i])
    list_district_in_thai.append(label['district_name_th'][i])
    list_subdistrict_in_thai.append(label['subdistrict_name_th'][i])

# clear dup
list_province_in_thai = list(dict.fromkeys(list_province_in_thai))

count = 0
query = """
    query storeList($pageOptions: PaginateInput, $query: JSON) {
        storeList(pageOptions: $pageOptions, query: $query) {
            storeList {
                storeDetail {
                    _id
                    name
                    latitude
                    longitude
                    location
                }
              
            }
          
        }
    }
"""
store_details = []
for i in list_province_in_thai:
    variables = {
        "pageOptions": {
            "page": 1,
            "itemPerPage": 100
        },
        "query": {
            "province": i
        }
    }
    data = {
        'query': query,
        'variables': variables
    }
    response = requests.post(url, headers=headers, json=data)
    for store in response.json()["data"]["storeList"]["storeList"]:
        for d  in store["storeDetail"]:
            location = d['location']
            location = location.replace("ต.", "ตำบล ")
            location = location.replace("ตำบล ", "ตำบล ")
            location = location.replace("ตำบล", "ตำบล ")
            location = location.replace("ตําบล", "ตำบล ")
            location = location.replace("แขวง", "ตำบล ")

            location = location.replace("อ.", "อำเภอ ")
            location = location.replace("อำเภอ ", "อำเภอ ")
            location = location.replace("อำเภอ", "อำเภอ ")
            location = location.replace("อําเภอ", "อำเภอ ")
            location = location.replace("เขต", "อำเภอ ")
            location = location.replace("เบต", "อำเภอ ")
            
            location = location.replace("จังหวัด", " จังหวัด")
            location = location.replace("จัหวัด", " จังหวัด")

            if d['_id'] =="62846c5194ff1d001c98a4b2":
                location = "169 ตำบล ทานตะวัน อำเภอ พาน เชียงราย 57280"
            elif d['_id'] =="6110f9cb1a46d6001cdf929a":
                location = "81 หมู่ที่ 6 ตำบล สว่างแดนดิน อำเภอ สว่างแดนดิน จังหวัดสกลนคร 47110"
            elif d['_id'] =="610a5b291a46d6001cdf86c2":
                location = "79 หมู่ที่ 1 ตำบล หนองโพธิ์ อำเภอ นาเชือก จังหวัดมหาสารคาม 44170"
            elif d['_id'] =="6110f9c91a46d6001cdf8909":
                location = "79 หมู่ที่ 1 ตำบล หนองโพธิ์ อำเภอ นาเชือก จังหวัดมหาสารคาม 44170"
            elif d['_id'] =="6135a5c382241e001ce28a7a":
                location = "149 หมู่ที่ 2 ตำบล เชียงกลม อำเภอ ปากชม จังหวัดเลย 42150"
            elif d['_id'] =="6110f9ca1a46d6001cdf902e":
                location = "64/5 หมู่ที่ 6 ตำบล ไม้ดัด อำเภอ บางระจัน จังหวัดสิงห์บุรี 16130"
            elif d['_id'] =="633550bbabc1ac001c80c021":
                location = "126 หมู่ที่ 8 ตำบล บ้านเกาะ อำเภอ เมืองอุตรดิตถ์ จังหวัดอุตรดิตถ์ 53000"
            elif d['_id'] =="633550bbabc1ac001c80c022":
                location = "126 หมู่ที่ 8 ตำบล บ้านเกาะ อำเภอ เมืองอุตรดิตถ์ จังหวัดอุตรดิตถ์ 53000"
            elif d['_id'] =="60ffcdb61cff09001cc2671c":
                location = "43 หมู่ที่ 2 ตำบล กบเจา อำเภอ บางบาล จังหวัดพระนครศรีอยุธยา 13250"
            elif d['_id'] =="6135a5c282241e001ce28573":
                location = "137/4 หมู่ที่ 3 ตำบล แกลง อำเภอ เมืองระยอง จังหวัด ระยอง 21160"

            location = location.replace("N/A", "-")
            
            d['location'] = location
            #print(location)
            address = location.split(' ')
            subdist_index = address.index('ตำบล')
            dist_index = address.index('อำเภอ')
            subdistrict = address[subdist_index+1]
            #print(subdistrict)
            district = address[dist_index+1]
            #print(district)
            if subdistrict == "":
                subdistrict = address[subdist_index+2]
            if district == "":
                district = address[dist_index+2]
            # เพิ่มข้อมูล 'province', 'district', 'subdistrict'
            d['province'] = i
            d['district'] = district
            d['subdistrict'] = subdistrict
            print (d)
            store_details.append(d)

df = pd.DataFrame(store_details)
df.to_excel(f'../excel/ถูกและดี/ถูกและดี({str(now.date())}).xlsx', index=False)
print("<---------------------------------------- COMPLETE ---------------------------------------->")
