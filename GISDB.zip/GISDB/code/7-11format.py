import glob
import pandas as pd
import  jpype     
import  asposecells     
import os
import pandas
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import create_engine
from datetime import datetime
import shutil
now = datetime.today()

# specifying the path to files
pathjson = "C:/Users/Tcct/Desktop/GISDB/csv/7-11"
pathexcel = "C:/Users/Tcct/Desktop/GISDB/excel/7-11/province"

#covert json to excel
for file in os.listdir(pathjson):
    if file.endswith(".json"):
        # Load the JSON data into a pandas DataFrame
        pandas.read_json(pathjson+"/"+file).to_excel(pathexcel+f"/{os.path.splitext(file)[0]}.xlsx")

        
# exel files in the path
file_list = glob.glob(pathexcel + "/*.xlsx")
 
# list of excel files we want to merge.
# pd.read_excel(file_path) reads the excel
# data into pandas dataframe.
excl_list = []
 
for file in file_list:
    excl_list.append(pd.read_excel(file))
    
# create a new dataframe to store the
# merged excel file.
excl_merged = pd.DataFrame()
 
for excl_file in excl_list:
     
    # appends the data into the excl_merged
    # dataframe.
    excl_merged = excl_merged.append(
      excl_file, ignore_index=True)
 
# exports the dataframe into excel file with
# specified name.
excl_merged.to_excel(f'C:/Users/Tcct/Desktop/GISDB/excel/7-11/7-11({str(now.date())}).xlsx', index=False)

#updateGIS
"""pathGis = 'C:/Users/Tcct/Desktop/GIS/GIS/ExpressMap-main/maplocation/public/json/store/7-11'
pathmanuscr = 'C:/Users/Tcct/Desktop/GISDB/trash/'
shutil.copyfile(pathmanuscr + f'/7-11{str(now.date())}.json', pathGis+'/7-11.json')

#7-11->db
path = '../GISDB/excel/7-11/7-11(2023-01-26).xlsx'
seven = pd.read_excel(path, header = 0)
engine = create_engine('mysql://root:@localhost:3306/7-11')
with engine.connect() as conn, conn.begin():
    seven.to_sql(f'7-11(2023-01-26)', conn, if_exists='append', index=False)
conn.close()
"""