import requests
import pandas as pd
from openpyxl import load_workbook
import re 
import csv
import json
import time
import re 
import csv
import json
import time
from datetime import datetime

now = datetime.today()

def getDatafromAPI():
    url = "https://www.jiffyapp.co/index.php/api/locations"
    headers = {'Accept': 'application/json, text/plain, */*'}
    params = {"store_format": "familymart" }
    response = requests.get(url, headers=headers , params=params)
    #response = requests.post(url, headers=headers)
    payload = response.json()
    with open("../trash/jiffy_raw.json"  , "w") as outfile:
        json.dump(payload, outfile)

getDatafromAPI()

j = open("../trash/jiffy_raw.json")
payload = json.load(j)
length = len(payload['responseData']['locations'])
def longdoAddress(lat,lng):
    url = "https://api.longdo.com/map/services/address?"
    params = {'lat': lat , 'lon' : lng , 'key' : '1917e02b4ab264ba547fecdd6e82b4aa'}
    response =requests.get(url, params=params)
    payload = response.json()
    #print("------------------------------------------")
    #print(payload)
    #print("------------------------------------------")
    province = removeWrongkeyword(payload['province'])
    district = removeWrongkeyword(payload['district'])
    subdistrict = removeWrongkeyword(payload['subdistrict'])
    try:
        postcode = payload['postcode']
        
    except :
        postcode = ""
    
    time.sleep(1)
    
    return province,district,subdistrict,postcode

def removeWrongkeyword(word):
    payload_word = word
    if(re.findall(r"\จ+[.]",word)):
        payload_word = re.sub(r"\จ+[.]","จังหวัด",word)
    elif(re.findall(r"\อ+[.]",word)):
        payload_word = re.sub(r"\อ+[.]","อำเภอ",word)
    elif(re.findall(r"\ต+[.]",word)):
        payload_word = re.sub(r"\ต+[.]","ตำบล",word)
    return payload_word

def checkwrongdata(store_id) :
    lat = ""
    lng = ""
    flag = False
    #wrong lat lng sections
    if(store_id == 22):
        lat = "13.81924339214209"
        lng = "100.73889232899852"
        flag = True
    elif(store_id == 373):
        lat = "15.0195700"
        lng = "100.3439990"
        flag = True
    elif(store_id == 387):
        lat = "12.696720956122096"
        lng = "101.19556768125194"
        flag = True
    elif(store_id == 391):
        lat = "13.897438759355188"
        lng = "101.5993422836568"
        flag = True
    elif(store_id == 486):
        lat = "13.629469647474897"
        lng = "101.31734438164948"
        flag = True
    return lat,lng,flag

def extracteachDetail(word):
    payload_word = word
    if(re.findall(r"\จังหวัด",payload_word)):
        payload_word = re.sub("จังหวัด","",payload_word)
    elif(re.findall(r"\อำเภอ",payload_word)):
        payload_word = re.sub("อำเภอ","",payload_word)
    elif(re.findall(r"\ตำบล",payload_word)):
        payload_word = re.sub("ตำบล","",payload_word)
    elif(re.findall(r"\เขต",payload_word)):
        payload_word = re.sub("เขต","",payload_word)
    elif(re.findall(r"\แขวง",payload_word)):
        payload_word = re.sub("แขวง","",payload_word)
        
    return payload_word

def findCode(province,district,subdistrict):
    
    province_code = None
    district_code = None
    subdistrict_code = None
    
    for l in range(len(label)):
        if( (province == label['name_th'][l]) and (district == label['district_name_th'][l]) and (subdistrict == label['subdistrict_name_th'][l])) :
            province_code = label['province_code'][l].item()
            district_code = label['district_code'][l].item()
            subdistrict_code = label['subdistrict_code'][l].item()
            
    return province_code,district_code,subdistrict_code

list_lat = []
list_lng = []
list_payload = []
list_dup = []
i = 0
data = payload['responseData']['locations']
while i < length :
    name = data[i]['location_name']
    store_id = data[i]['location_id']
    lat = data[i]['location_lat']
    lng = data[i]['location_lng']
    
    if(re.findall(r'\t',lat)):
        lat = re.sub(r'\t',"",lat)
    if(re.findall(r'\t',lng)):
        lng = re.sub(r'\t',"",lng)

    if(lat not in list_lat) and (lng not in list_lng):
        check_name = name.lower()
        if re.findall("pearly tea",check_name):
            print("id: " + store_id)
            print("###################")
        list_lat.append(lat)
        list_lng.append(lng)
        dict_payload = {'name' : name , 'id' : store_id , 'lat': lat , 'lng' : lng}
        list_payload.append(dict_payload)
    else :
        list_dup.append(store_id)
    i = i + 1

list_missing = [41,43,363,366,378,383,386,393,394,395,396,397,398,399,400,401,402,403,404,405,406,407,408,409,410,411,412,413,414,415,416,417,418,419,420,421,422,423]
list_dupwithmissingString = [426,429,434,443,446,470,473,482,483,484]

j = 0
count = 0
list_del = []
while j < len(list_payload) :
    store_id = int(list_payload[j]['id'])
    if(store_id in list_missing) or (store_id in list_dupwithmissingString):
        list_del.append(list_payload[j])
        count = count + 1

    lat,lng,flag = checkwrongdata(store_id)
    
    if(flag):
        print(store_id)
        list_payload[j]['lat'] = lat
        list_payload[j]['lng'] = lng


    j = j + 1
    
for key in list_del :
    list_payload.remove(key)

label = pd.read_excel('../code/geocodelabel.xlsx', index_col=None) 

i = 0
count = 0
data = payload['responseData']['locations']
list_output = []
while i < len(data) :
    j = 0
    while j < len(list_payload) :
        if(data[i]['location_id']) == list_payload[j]['id'] :
            branch_name = list_payload[j]['name']
            print("-----------------------")
            print(branch_name)
            print(i)
            print(j)
            print("-----------------------")
            store_id = list_payload[j]['id']
            address = data[i]['location_address']
            lat = list_payload[j]['lat']
            lng = list_payload[j]['lng']
            lat = lat.replace(" ","")
            lng = lng.replace(" ","")
            province,district,subdistrict,_ = longdoAddress(lat,lng)
            
            province = extracteachDetail(province)
            district = extracteachDetail(district)
            subdistrict = extracteachDetail(subdistrict)
            
            province_code,district_code,subdistrict_code = findCode(province,district,subdistrict)
            
            format_store = "Convenience Stores"
            branch_type = "Jiffy"
            owner = "PTT"
            

            dict_payload = {'name' : branch_name , 'store_id' : store_id , 'type' : branch_type , 'format' : format_store,
                               'owner' : owner , 'address': address , 'lat' : float(lat) , 'lng' : float(lng) , 'province' : province ,
                               'district' :  district  , 'subdistrict' : subdistrict }
                
            
            list_output.append(dict_payload)

        j = j + 1
        
    
    i = i + 1

with open("../trash/%s.json" % branch_type  , "w") as outfile:
        json.dump(list_output, outfile)
"""
#jsontoexcel
df_json =  pd.read_json(f"../trash/Jiffy.json")
df_json.to_excel(f"../excel/jiffy/Jiffy.{str(now.date())}.xlsx")
"""